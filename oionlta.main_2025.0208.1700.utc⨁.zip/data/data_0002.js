
/////////////////////////////////////////////////
///	DATA: MEDIA

/////////////////////////////////////////////////

var data_0002 = {

/////////////////////////////////////////////////
__FILENAME__:{
///__DATE__,__DESC__,__ELM__,__FILE_TYPE__,__FILENAME__,__TITLE__
alt:		'__DESC__', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'__DATE__.utc⨁', 
decoding:	'', 
desc:		'__DESC__', 
elm:		'__ELM__', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/__FILENAME__.__FILE_TYPE__', 
srcset:[
		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	], 
title:		'__TITLE__', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/__FILE_TYPE__', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/__FILENAME__.__FILE_TYPE__', 
		mime_type:	'image/png', 
		title:		'__TITLE__', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__',
	content_html:	'<p>__DESC__</p>', 
	content_text:	'__DESC__', 
	date_modified:	'__DATE__.utc⨁', 
	date_published:	'__DATE__.utc⨁', 
	external_url:	'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	id:		'__FILENAME__', 
	image:		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	language:	'en-US', 
	summary:	'__DESC__', 
	tags:		[ '__TITLE__', '__DESC__', '__FILE_GROUP__', '__FILE_TYPE__', ], 
	title:		'__TITLE__', 
	url:		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	}, 

},



/////////////////////////////////////////////////
mov_0205_0000:{ 
alt:		'About Oion LTA', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'A short video about Oion Learning & Training Academy', 
elm:		'video', 
fetchpriority:	'low', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'true', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/mov_0205_0000.mov', 
srcset:[
	], 
title:		'About Oion LTA', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'video/mov', 
usemap:		'', 
width:		'window', 
wci:{ 
	attachments:[ { 
		url:		'./media/mov_0205_0000.mov', 
		mime_type:	'video/mov', 
		title:		'About Oion LTA', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'https://media.oionlta.app/media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/mov_0205_0000/banner_image.png',
	content_html:	'<p>About Oion LTA</p>', 
	content_text:	'About Oion LTA', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/mov_0205_0000.mov', 
	id:		'mov_0205_0000', 
	image:		'https://media.oionlta.app/media/mov_0205_0000_banner_image.png', 
	language:	'en-US', 
	summary:	'About Oion LTA', 
	tags:		[ 'About', '__TAGS_OF_THE_MEDIA__', ], 
	title:		'About Oion LTA', 
	url:		'https://media.oionlta.app/media/mov_0205_0000.mov', 
	}, 
},



/////////////////////////////////////////////////
wav_0205_0000:{ 
alt:		'About Oion LTA', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'A short audio clip about Oion Learning & Training Academy', 
elm:		'audio', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'true', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/wav_0205_0000.wav', 
srcset:[
	], 
title:		'About Oion LTA', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'audio/wav', 
usemap:		'', 
width:		'window', 
wci:{ 
	attachments:[ { 
		url:		'./media/wav_0205_0000.wav', 
		mime_type:	'audio/wav', 
		title:		'About Oion LTA', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/wav_0205_0000_banner_image.png',
	content_html:	'<p>About Oion LTA</p>', 
	content_text:	'About Oion LTA', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/wav_0205_0000.wav', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/wav_0205_0000.wav', 
	language:	'en-US', 
	summary:	'About Oion LTA', 
	tags:		[ 'About', 'Learning', 'Oion LTA',  ], 
	title:		'About Oion LTA', 
	url:		'https://media.oionlta.app/media/wav_0205_0000.wav', 
	}, 
},



/////////////////////////////////////////////////
png_0000_0000:{

alt:		'Grid Globe logo', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'A globe with grid lines.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0000_0000.png', 
srcset:[
		'https://media.oionlta.app/media/png_mmdd_0000.png', 
		'https://media.oionlta.app/media/png_mmdd_0001.png', 
	], 
title:		'Oion LTA', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'image/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0000_0000.png', 
		mime_type:	'image/png', 
		title:		'Oion LTA', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0000_0000.png',
	content_html:	'<p>Oion LTA</p>', 
	content_text:	'Oion LTA', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0000_0000.png', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/png_0000_0000.png', 
	language:	'en-US', 
	summary:	'Oion LTA logo', 
	tags:		[ 'Oion LTA', 'training', 'language learning', 'learning',  ], 
	title:		'Oion LTA', 
	url:		'https://media.oionlta.app/media/png_0000_0000.png', 
	}, 

},


/////////////////////////////////////////////////
png_0205_0001:{
alt:		'Globe on Europe with text reading `Russian`', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'Globe on Europe with text reading `Russian`', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0205_0001.png', 
srcset:[
		'https://media.oionlta.app/media/png_mmdd_0000.png', 
		'https://media.oionlta.app/media/png_mmdd_0001.png', 
	], 
title:		'Russian Language Learning', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'image/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0205_0001.png', 
		mime_type:	'image/png', 
		title:		'Russian Language Learning', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0205_0001.png',
	content_html:	'<p>Russian Language Learning</p>', 
	content_text:	'Russian Language Learning', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0205_0001.png', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/png_0205_0001.png', 
	language:	'en-US', 
	summary:	'__SUMMARY__', 
	tags:		[ 'Russian Language Learning', 'Language Learning', 'Russian', ], 
	title:		'Russian Language Learning', 
	url:		'https://media.oionlta.app/media/png_0205_0001.png', 
	}, 
},


/////////////////////////////////////////////////png_0205_0002:{
alt:		'Globe on asia without text', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'Globe on asia without text', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0205_0002.png', 
srcset:[
		'https://media.oionlta.app/media/png_mmdd_0000.png', 
		'https://media.oionlta.app/media/png_mmdd_0001.png', 
	], 
title:		'Language Learning', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'image/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0205_0002.png', 
		mime_type:	'image/png', 
		title:		'Language Learning', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0205_0002.png',
	content_html:	'<p>Language Learning</p>', 
	content_text:	'Language Learning', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0205_0002.png', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/png_0205_0002.png', 
	language:	'en-US', 
	summary:	'Language Learning, Globe on asia without text', 
	tags:		[ 'Language Learning', 'Learning', ], 
	title:		'Language Learning', 
	url:		'https://media.oionlta.app/media/png_0205_0002.png', 
	}, 
},

/////////////////////////////////////////////////
png_0205_0003:{
alt:		'Globe on South America with text reading `Spanish`', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'Globe on South America with text reading `Spanish`', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0205_0003.png', 
srcset:[
		'https://media.oionlta.app/media/png_mmdd_0000.png', 
		'https://media.oionlta.app/media/png_mmdd_0001.png', 
	], 
title:		'Spanish Language Learning', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'image/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0205_0003.png', 
		mime_type:	'image/png', 
		title:		'Spanish Language Learning', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0205_0003.png',
	content_html:	'<p>Globe on South America with text reading `Spanish`</p>', 
	content_text:	'Globe on South America with text reading `Spanish`', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0205_0003.png', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/png_0205_0003.png', 
	language:	'en-US', 
	summary:	'Globe on South America with text reading `Spanish`', 
	tags:		[ 'Spanish Language Learning', 'Spanish', 'Language Learning', ], 
	title:		'Spanish Language Learning', 
	url:		'https://media.oionlta.app/media/png_0205_0003.png', 
	}, 
},



/////////////////////////////////////////////////
png_0206_0000:{

alt:		'Globe on Europe with text reading FRENCH', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'Globe on Europe with text reading FRENCH', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0206_0000.png', 
srcset:[
		'https://media.oionlta.app/media/png_mmdd_0000.png', 
		'https://media.oionlta.app/media/png_mmdd_0001.png', 
	], 
title:		'French Language Learning', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'image/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0206_0000.png', 
		mime_type:	'image/png', 
		title:		'French Language Learning', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0206_0000.png',
	content_html:	'<p>French Language Learning</p>', 
	content_text:	'French Language Learning', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0206_0000.png', 
	id:		'png_0206_0000', 
	image:		'https://media.oionlta.app/media/png_0206_0000.png', 
	language:	'en-US', 
	summary:	'French Language Learning', 
	tags:		[ 'French Language Learning', 'training', 'language learning', 'learning',  ], 
	title:		'French Language Learning', 
	url:		'https://media.oionlta.app/media/png_0206_0000.png', 
	}, 

},



/////////////////////////////////////////////////
png_0206_0001:{

alt:		'Globe on Europe with text reading GERMAN', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0206.1700.utc⨁', 
decoding:	'', 
desc:		'Globe on Europe with text reading GERMAN', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0206_0001.png', 
srcset:[
		'https://media.oionlta.app/media/png_0206_0001.png', 
	], 
title:		'German Language Learning', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0206_0001.png', 
		mime_type:	'image/png', 
		title:		'German Language Learning', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0206_0001.png',
	content_html:	'<p>Globe on Europe with text reading GERMAN</p>', 
	content_text:	'Globe on Europe with text reading GERMAN', 
	date_modified:	'2025.0206.1700.utc⨁', 
	date_published:	'2025.0206.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0206_0001.png', 
	id:		'png_0206_0001', 
	image:		'https://media.oionlta.app/media/png_0206_0001.png', 
	language:	'en-US', 
	summary:	'Globe on Europe with text reading GERMAN', 
	tags:		[ 'German Language Learning', 'Globe on Europe with text reading GERMAN', '__FILE_GROUP__', 'png', ], 
	title:		'German Language Learning', 
	url:		'https://media.oionlta.app/media/png_0206_0001.png', 
	}, 

},



/////////////////////////////////////////////////
png_0206_0003:{

alt:		'Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0206.1700.utc⨁', 
decoding:	'', 
desc:		'Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0206_0003.png', 
srcset:[
		'https://media.oionlta.app/media/png_0206_0003.png', 
	], 
title:		'Three Triangles', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0206_0003.png', 
		mime_type:	'image/png', 
		title:		'Three Triangles', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0206_0003.png',
	content_html:	'<p>Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  </p>', 
	content_text:	'Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  ', 
	date_modified:	'2025.0206.1700.utc⨁', 
	date_published:	'2025.0206.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0206_0003.png', 
	id:		'png_0206_0003', 
	image:		'https://media.oionlta.app/media/png_0206_0003.png', 
	language:	'en-US', 
	summary:	'Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  ', 
	tags:		[ 'Three Triangles', 'Three equalatiral triangles of blue with yellow tips, overlapped & rotation offset by about 10 degrees, on a gray circle.  ', '__FILE_GROUP__', 'png', ], 
	title:		'Three Triangles', 
	url:		'https://media.oionlta.app/media/png_0206_0003.png', 
	}, 

},



/////////////////////////////////////////////////
png_0206_0004:{

alt:		'Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0206.1700.utc⨁', 
decoding:	'', 
desc:		'Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0206_0004.png', 
srcset:[
		'https://media.oionlta.app/media/png_0206_0004.png', 
	], 
title:		'Volvox', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0206_0004.png', 
		mime_type:	'image/png', 
		title:		'Volvox', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0206_0004.png',
	content_html:	'<p>Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  </p>', 
	content_text:	'Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  ', 
	date_modified:	'2025.0206.1700.utc⨁', 
	date_published:	'2025.0206.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0206_0004.png', 
	id:		'png_0206_0004', 
	image:		'https://media.oionlta.app/media/png_0206_0004.png', 
	language:	'en-US', 
	summary:	'Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  ', 
	tags:		[ 'Volvox', 'Sixteen large light green lozenges concentric around sixteen small light green lozenges, concentric around a smaller light green blurry circle, some breaking away in the upper right corner.  ', '__FILE_GROUP__', 'png', ], 
	title:		'Volvox', 
	url:		'https://media.oionlta.app/media/png_0206_0004.png', 
	}, 

},



/////////////////////////////////////////////////
png_0206_0005:{

alt:		'Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0206.1700.utc⨁', 
decoding:	'', 
desc:		'Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0206_0005.png', 
srcset:[
		'https://media.oionlta.app/media/png_0206_0005.png', 
	], 
title:		'Circle Trefoil', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0206_0005.png', 
		mime_type:	'image/png', 
		title:		'Circle Trefoil', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0206_0005.png',
	content_html:	'<p>Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  </p>', 
	content_text:	'Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  ', 
	date_modified:	'2025.0206.1700.utc⨁', 
	date_published:	'2025.0206.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0206_0005.png', 
	id:		'png_0206_0005', 
	image:		'https://media.oionlta.app/media/png_0206_0005.png', 
	language:	'en-US', 
	summary:	'Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  ', 
	tags:		[ 'Circle Trefoil', 'Three circles, green top, orange left, & blue right, overlapping each other about 5 percent, in the counter clockwise direction, similar to a trefoil.  ', '__FILE_GROUP__', 'png', ], 
	title:		'Circle Trefoil', 
	url:		'https://media.oionlta.app/media/png_0206_0005.png', 
	}, 

},




srcset:[
	'./media/png_0000_0000.png', 	'./media/png_0205_0001.png', 	'./media/png_0205_0003.png', 	'./media/png_0206_0000.png', 	'./media/png_0206_0001.png', 	'./media/png_0206_0003.png', 	'./media/png_0206_0004.png', 	'./media/png_0206_0005.png', 
	], 
};
/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	data_diagnostic_0002.style.display = 		'none';

/////////////////////////////////////////////////
