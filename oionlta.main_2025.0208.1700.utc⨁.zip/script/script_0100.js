/////////////////////////////////////////////////
///	SECTION 0000:  
///	APPEND, ALL SECTIONS, 

/////////////////////////////////////////////////

	tbody_0000.append( tr_0000 );
	tr_0000.append( td_0000 );
	tr_0000.append( td_0001 );
	td_0000.append( box_0000 );
	td_0001.append( media_0000 );
	box_0000.append( text_0000 );

/////////////////////////////////////////////////

	section_1000.append( link_1000 );
	section_1000.append( link_1001 );
	section_1000.append( link_1002 );
	section_1000.append( link_1003 );
	section_1000.append( link_1004 );
	section_1000.append( link_1005 );
	section_1000.append( link_1006 );
	section_1000.append( link_1007 );
	section_1000.append( link_1008 );
	section_1000.append( link_1009 );

	link_1000.append( box_1000 );
	link_1001.append( box_1001 );
	link_1002.append( box_1002 );
	link_1003.append( box_1003 );
	link_1004.append( box_1004 );
	link_1005.append( box_1005 );
	link_1006.append( box_1006 );
	link_1007.append( box_1007 );
	link_1008.append( box_1008 );
	link_1009.append( box_1009 );

	box_1000.append( text_1000 );
	box_1001.append( text_1001 );
	box_1002.append( text_1002 );
	box_1003.append( text_1003 );
	box_1004.append( text_1004 );
	box_1005.append( text_1005 );
	box_1006.append( text_1006 );
	box_1007.append( text_1007 );
	box_1008.append( text_1008 );
	box_1009.append( text_1009 );

/////////////////////////////////////////////////

	section_2000.append( link_2000 );
	section_2000.append( link_2001 );
	section_2000.append( link_2002 );
	section_2000.append( link_2003 );
	section_2000.append( link_2004 );
	section_2000.append( link_2005 );
	section_2000.append( link_2006 );
	section_2000.append( link_2007 );
	section_2000.append( link_2008 );
	section_2000.append( link_2009 );

	link_2000.append( box_2000 );
	link_2001.append( media_0021 );
	link_2002.append( media_0022 );
	link_2003.append( media_0023 );
	link_2004.append( media_0024 );
	link_2005.append( media_0025 );
	link_2006.append( media_0026 );
	link_2007.append( media_0027 );
	link_2008.append( media_0028 );
	link_2009.append( media_0029 );

	box_2000.append( text_2000 );
	media_0021.append( text_2001 );
	media_0022.append( text_2002 );
	media_0023.append( text_2003 );
	media_0024.append( text_2004 );
	media_0025.append( text_2005 );
	media_0026.append( text_2006 );
	media_0027.append( text_2007 );
	media_0028.append( text_2008 );
	media_0029.append( text_2009 );

/////////////////////////////////////////////////

	section_3000.append( link_3000 );
	section_3000.append( link_3001 );
	section_3000.append( link_3002 );
	section_3000.append( link_3003 );
	section_3000.append( link_3004 );
	section_3000.append( link_3005 );
/*
	section_3000.append( link_3006 );
	section_3000.append( link_3007 );
	section_3000.append( link_3008 );
	section_3000.append( link_3009 );
*/
	link_3000.append( box_3000 );
	link_3001.append( box_3001 );
	link_3002.append( box_3002 );
	link_3003.append( box_3003 );
	link_3004.append( box_3004 );
	link_3005.append( box_3005 );
	link_3006.append( box_3006 );
	link_3007.append( box_3007 );
	link_3008.append( box_3008 );
	link_3009.append( box_3009 );

	box_3000.append( text_3000 );
	box_3001.append( text_3001 );
	box_3002.append( text_3002 );
	box_3003.append( text_3003 );
	box_3004.append( text_3004 );
	box_3005.append( text_3005 );
	box_3006.append( text_3006 );
	box_3007.append( text_3007 );
	box_3008.append( text_3008 );
	box_3009.append( text_3009 );

	section_3000.append( audio_0030 );
	section_3000.append( video_0030 );

/////////////////////////////////////////////////
/*
	section_4000.append( link_4000 );
	section_4000.append( media_0040 );
	section_4000.append( media_0041 );
	section_4000.append( media_0042 );
	section_4000.append( link_4004 );

	link_4000.append( box_4000 );
	link_4004.append( box_4004 );

	box_4000.append( text_4000 );
	box_4004.append( text_4004 );
*/
	section_4000.append( link_4000 );
	section_4000.append( link_4001 );
	section_4000.append( link_4002 );
	section_4000.append( link_4003 );
	section_4000.append( link_4004 );

	link_4000.append( box_4000 );
	link_4001.append( box_4001 );
	link_4002.append( media_0041 );
	link_4003.append( box_4003 );
	link_4004.append( box_4004 );

	box_4000.append( text_4000 );
	box_4001.append( text_4001 );
	media_0041.append( text_4002 );
	box_4003.append( text_4003 );
	box_4004.append( text_4004 );


/////////////////////////////////////////////////

	section_5000.append( link_5000 );
	section_5000.append( link_5001 );
	section_5000.append( link_5002 );
	section_5000.append( link_5003 );
	section_5000.append( link_5004 );
	section_5000.append( link_5005 );
	section_5000.append( link_5006 );
	section_5000.append( link_5007 );
	section_5000.append( link_5008 );
	section_5000.append( link_5009 );

	link_5000.append( box_5000 );
	link_5001.append( box_5001 );
	link_5002.append( box_5002 );
	link_5003.append( box_5003 );
	link_5004.append( box_5004 );
	link_5005.append( box_5005 );
	link_5006.append( box_5006 );
	link_5007.append( box_5007 );
	link_5008.append( box_5008 );
	link_5009.append( box_5009 );

	box_5000.append( text_5000 );
	box_5001.append( text_5001 );
	box_5002.append( text_5002 );
	box_5003.append( text_5003 );
	box_5004.append( text_5004 );
	box_5005.append( text_5005 );
	box_5006.append( text_5006 );
	box_5007.append( text_5007 );
	box_5008.append( text_5008 );
	box_5009.append( text_5009 );

/////////////////////////////////////////////////

	section_6000.append( link_6000 );
	section_6000.append( link_6001 );
	section_6000.append( link_6002 );
	section_6000.append( link_6003 );
	section_6000.append( link_6004 );
	section_6000.append( link_6005 );
	section_6000.append( link_6006 );
	section_6000.append( link_6007 );
	section_6000.append( link_6008 );
	section_6000.append( link_6009 );

	link_6000.append( box_6000 );
	link_6001.append( box_6001 );
	link_6002.append( box_6002 );
	link_6003.append( box_6003 );
	link_6004.append( box_6004 );
	link_6005.append( box_6005 );
	link_6006.append( box_6006 );
	link_6007.append( box_6007 );
	link_6008.append( box_6008 );
	link_6009.append( box_6009 );

	box_6000.append( text_6000 );
	box_6001.append( text_6001 );
	box_6002.append( text_6002 );
	box_6003.append( text_6003 );
	box_6004.append( text_6004 );
	box_6005.append( text_6005 );
	box_6006.append( text_6006 );
	box_6007.append( text_6007 );
	box_6008.append( text_6008 );
	box_6009.append( text_6009 );

/////////////////////////////////////////////////

	section_7000.append( link_7000 );
	section_7000.append( link_7001 );
	section_7000.append( link_7002 );
	section_7000.append( link_7003 );
	section_7000.append( link_7004 );
	section_7000.append( link_7005 );
	section_7000.append( link_7006 );
	section_7000.append( link_7007 );
	section_7000.append( link_7008 );
	section_7000.append( link_7009 );

	link_7000.append( box_7000 );
	link_7001.append( box_7001 );
	link_7002.append( box_7002 );
	link_7003.append( box_7003 );
	link_7004.append( box_7004 );
	link_7005.append( box_7005 );
	link_7006.append( box_7006 );
	link_7007.append( box_7007 );
	link_7008.append( box_7008 );
	link_7009.append( box_7009 );

	box_7000.append( text_7000 );
	box_7001.append( text_7001 );
	box_7002.append( text_7002 );
	box_7003.append( text_7003 );
	box_7004.append( text_7004 );
	box_7005.append( text_7005 );
	box_7006.append( text_7006 );
	box_7007.append( text_7007 );
	box_7008.append( text_7008 );
	box_7009.append( text_7009 );

/////////////////////////////////////////////////

	section_8000.append( link_8000 );
	section_8000.append( link_8001 );
	section_8000.append( link_8002 );
	section_8000.append( link_8003 );
	section_8000.append( link_8004 );
	section_8000.append( link_8005 );
	section_8000.append( link_8006 );
	section_8000.append( link_8007 );
	section_8000.append( link_8008 );
	section_8000.append( link_8009 );

	link_8000.append( box_8000 );
	link_8001.append( box_8001 );
	link_8002.append( box_8002 );
	link_8003.append( box_8003 );
	link_8004.append( box_8004 );
	link_8005.append( box_8005 );
	link_8006.append( box_8006 );
	link_8007.append( box_8007 );
	link_8008.append( box_8008 );
	link_8009.append( box_8009 );

	box_8000.append( text_8000 );
	box_8001.append( text_8001 );
	box_8002.append( text_8002 );
	box_8003.append( text_8003 );
	box_8004.append( text_8004 );
	box_8005.append( text_8005 );
	box_8006.append( text_8006 );
	box_8007.append( text_8007 );
	box_8008.append( text_8008 );
	box_8009.append( text_8009 );

/////////////////////////////////////////////////

	section_9000.append( link_9000 );
	section_9000.append( link_9001 );
	section_9000.append( link_9002 );
	section_9000.append( link_9003 );
	section_9000.append( link_9004 );
	section_9000.append( link_9005 );
	section_9000.append( link_9006 );
	section_9000.append( link_9007 );
	section_9000.append( link_9008 );
	section_9000.append( link_9009 );

	link_9000.append( box_9000 );
	link_9001.append( box_9001 );
	link_9002.append( box_9002 );
	link_9003.append( box_9003 );
	link_9004.append( box_9004 );
	link_9005.append( box_9005 );
	link_9006.append( box_9006 );
	link_9007.append( box_9007 );
	link_9008.append( box_9008 );
	link_9009.append( box_9009 );

	box_9000.append( text_9000 );
	box_9001.append( text_9001 );
	box_9002.append( text_9002 );
	box_9003.append( text_9003 );
	box_9004.append( text_9004 );
	box_9005.append( text_9005 );
	box_9006.append( text_9006 );
	box_9007.append( text_9007 );
	box_9008.append( text_9008 );
	box_9009.append( text_9009 );

/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0100.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
