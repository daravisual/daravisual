
/////////////////////////////////////////////////
///	SECTION 0000
///	STYLE SECTION:	Beige bg, 
///	STYLE SECTION:	black text on white bg, event inverse,  
///	STYLE FONT:	Baskerville, 
///	STYLE LINK:	none, 
///	NOTE:		MUST ASSIGN IN ORDER ( TEXT, BOX, LINK, SECTION ), FOR WRAPPED ELMS

/////////////////////////////////////////////////
///	SECTION
function fn_0500_section( x ){
	x.style.backgroundColor = 	'#FFFFF0';		///BEIGE
	x.style.border = 		'solid 0.25mm #000007';	///solid,dotted,double,groove,
	x.style.borderRadius = 		'1mm';
///	x.style.boxShadow = 		'-0.5mm 1mm 1mm #00ABBA';
	x.style.maxHeight = 		'window';			///window,fit-content,7mm,'', 
	x.style.height = 		'fit-content';			///window,fit-content,7mm,'', 
	x.style.margin = 		'1mm';		///auto
	x.style.padding = 		'3mm';
	x.style.position = 		'center';
	x.style.textAlign = 		'center';		///start,end,left,right,center
	x.style.maxWidth = 		'window';			///window,fit-content,7mm,'', 
	x.style.width = 		'window';			///window,fit-content,7mm,'', 
	x.style.verticalAlign = 	'middle';		///fit-content';
	///////	font,inset,textBaseline,writingMode,borderTLBR,
};

/////////////////////////////////////////////////
///	BOX
function fn_0500_box( x ){
	x.style.backgroundColor = 	'#FFFFFF';		///WHITE
	x.style.border = 		'solid 0.25mm #000007';	///solid,dotted,double,groove,
	x.style.borderRadius = 		'1mm';
///	x.style.boxShadow = 		'-0.5mm 1mm 1mm #00ABBA';
	x.style.maxHeight = 		'window';		///window,fit-content,7mm,'', 
	x.style.height = 		'fit-content';			///window,fit-content,7mm,'', 
	x.style.margin = 		'1mm';		///auto
	x.style.padding = 		'3mm';
	x.style.position = 		'center';
	x.style.textAlign = 		'center';		///start,end,left,right,center
	x.style.maxWidth = 		'window';			///window,fit-content,7mm,'', 
	x.style.width = 		'window';			///window,fit-content,7mm,'', 
	x.style.verticalAlign = 	'middle';		///fit-content
	///////	font,inset,textBaseline,writingMode,borderTLBR,
};


/////////////////////////////////////////////////
///	TEXT
function fn_0500_text( x ){
	x.style.color = 		'#000007';	///BLACK
	x.style.fontFamily = 		'Proxima Nova';	///Proxima Nova,Courier New,Optima,Baskerville,Snell Roundhand,
	x.style.fontSize = 		'4mm';
	x.style.fontVariantCaps = 	'optimizeSpeed';///small-caps,all-small-caps,unicase,titling-caps,optimizeSpeed,
	x.style.fontWeight = 		'none';		///none,400,initial,bold,bolder
///	x.style.letterSpacing = 	'0.5mm';
///	x.style.lineHeight = 		'1mm';
	x.style.textAlign = 		'center';	///start,end,left,right,center,justify
	x.style.textBaseline = 		'ideographic';	///top,hanging,middle,ideographic,bottom
	x.style.textDecoration = 	'none';	
///	x.style.textIndent = 		'3mm';
///	x.style.textShadow = 		'-0.25mm 0.25mm 0.25mm #00ABBA';
///	x.style.textTransform = 	'';
///	x.style.whiteSpace = 		'';
///	x.style.wordSpacing = 		'3mm';
	x.style.verticalAlign = 	'middle';	///fit-content';
	///////	maxHeight,height,inset,margin,padding,position,maxWidth,width,borderTLBR
};


/////////////////////////////////////////////////
///	TEXT ASSIGN

	fn_0500_text( text_0000 );
	fn_0500_text( text_0001 );
	fn_0500_text( text_0002 );

	fn_0500_text( text_1000 );
	fn_0500_text( text_1001 );
	fn_0500_text( text_1002 );
	fn_0500_text( text_1003 );
	fn_0500_text( text_1004 );
	fn_0500_text( text_1005 );
	fn_0500_text( text_1006 );
	fn_0500_text( text_1007 );
	fn_0500_text( text_1008 );
	fn_0500_text( text_1009 );

	fn_0500_text( text_2000 );
	fn_0500_text( text_2001 );
	fn_0500_text( text_2002 );
	fn_0500_text( text_2003 );
	fn_0500_text( text_2004 );
	fn_0500_text( text_2005 );
	fn_0500_text( text_2006 );
	fn_0500_text( text_2007 );
	fn_0500_text( text_2008 );
	fn_0500_text( text_2009 );

	fn_0500_text( text_3000 );
	fn_0500_text( text_3001 );
	fn_0500_text( text_3002 );
	fn_0500_text( text_3003 );
	fn_0500_text( text_3004 );
	fn_0500_text( text_3005 );
	fn_0500_text( text_3006 );
	fn_0500_text( text_3007 );
	fn_0500_text( text_3008 );
	fn_0500_text( text_3009 );

	fn_0500_text( text_4000 );
	fn_0500_text( text_4001 );
	fn_0500_text( text_4002 );
	fn_0500_text( text_4003 );
	fn_0500_text( text_4004 );
	fn_0500_text( text_4005 );
	fn_0500_text( text_4006 );
	fn_0500_text( text_4007 );
	fn_0500_text( text_4008 );
	fn_0500_text( text_4009 );

	fn_0500_text( text_5000 );
	fn_0500_text( text_5001 );
	fn_0500_text( text_5002 );
	fn_0500_text( text_5003 );
	fn_0500_text( text_5004 );
	fn_0500_text( text_5005 );
	fn_0500_text( text_5006 );
	fn_0500_text( text_5007 );
	fn_0500_text( text_5008 );
	fn_0500_text( text_5009 );

	fn_0500_text( text_6000 );
	fn_0500_text( text_6001 );
	fn_0500_text( text_6002 );
	fn_0500_text( text_6003 );
	fn_0500_text( text_6004 );
	fn_0500_text( text_6005 );
	fn_0500_text( text_6006 );
	fn_0500_text( text_6007 );
	fn_0500_text( text_6008 );
	fn_0500_text( text_6009 );

	fn_0500_text( text_7000 );
	fn_0500_text( text_7001 );
	fn_0500_text( text_7002 );
	fn_0500_text( text_7003 );
	fn_0500_text( text_7004 );
	fn_0500_text( text_7005 );
	fn_0500_text( text_7006 );
	fn_0500_text( text_7007 );
	fn_0500_text( text_7008 );
	fn_0500_text( text_7009 );

	fn_0500_text( text_8000 );
	fn_0500_text( text_8001 );
	fn_0500_text( text_8002 );
	fn_0500_text( text_8003 );
	fn_0500_text( text_8004 );
	fn_0500_text( text_8005 );
	fn_0500_text( text_8006 );
	fn_0500_text( text_8007 );
	fn_0500_text( text_8008 );
	fn_0500_text( text_8009 );

	fn_0500_text( text_9000 );
	fn_0500_text( text_9001 );
	fn_0500_text( text_9002 );
	fn_0500_text( text_9003 );
	fn_0500_text( text_9004 );
	fn_0500_text( text_9005 );
	fn_0500_text( text_9006 );
	fn_0500_text( text_9007 );
	fn_0500_text( text_9008 );
	fn_0500_text( text_9009 );


/////////////////////////////////////////////////
///	BOX ASSIGN

	fn_0500_box( box_1000 );
	fn_0500_box( box_1001 );
	fn_0500_box( box_1002 );
	fn_0500_box( box_1003 );
	fn_0500_box( box_1004 );
	fn_0500_box( box_1005 );
	fn_0500_box( box_1006 );
	fn_0500_box( box_1007 );
	fn_0500_box( box_1008 );
	fn_0500_box( box_1009 );

	///
	fn_0500_box( box_2001 );
	fn_0500_box( box_2002 );
	fn_0500_box( box_2003 );
	fn_0500_box( box_2004 );
	fn_0500_box( box_2005 );
	fn_0500_box( box_2006 );
	fn_0500_box( box_2007 );
	fn_0500_box( box_2008 );
	fn_0500_box( box_2009 );

	fn_0500_box( box_3000 );
	fn_0500_box( box_3001 );
	fn_0500_box( box_3002 );
	fn_0500_box( box_3003 );
	fn_0500_box( box_3004 );
	fn_0500_box( box_3005 );
	fn_0500_box( box_3006 );
	fn_0500_box( box_3007 );
	fn_0500_box( box_3008 );
	fn_0500_box( box_3009 );

	fn_0500_box( box_4000 );
	fn_0500_box( box_4001 );
	fn_0500_box( box_4002 );
	fn_0500_box( box_4003 );
	fn_0500_box( box_4004 );
	fn_0500_box( box_4005 );
	fn_0500_box( box_4006 );
	fn_0500_box( box_4007 );
	fn_0500_box( box_4008 );
	fn_0500_box( box_4009 );

	fn_0500_box( box_5000 );
	fn_0500_box( box_5001 );
	fn_0500_box( box_5002 );
	fn_0500_box( box_5003 );
	fn_0500_box( box_5004 );
	fn_0500_box( box_5005 );
	fn_0500_box( box_5006 );
	fn_0500_box( box_5007 );
	fn_0500_box( box_5008 );
	fn_0500_box( box_5009 );

	fn_0500_box( box_6000 );
	fn_0500_box( box_6001 );
	fn_0500_box( box_6002 );
	fn_0500_box( box_6003 );
	fn_0500_box( box_6004 );
	fn_0500_box( box_6005 );
	fn_0500_box( box_6006 );
	fn_0500_box( box_6007 );
	fn_0500_box( box_6008 );
	fn_0500_box( box_6009 );

	fn_0500_box( box_7000 );
	fn_0500_box( box_7001 );
	fn_0500_box( box_7002 );
	fn_0500_box( box_7003 );
	fn_0500_box( box_7004 );
	fn_0500_box( box_7005 );
	fn_0500_box( box_7006 );
	fn_0500_box( box_7007 );
	fn_0500_box( box_7008 );
	fn_0500_box( box_7009 );

	fn_0500_box( box_8000 );
	fn_0500_box( box_8001 );
	fn_0500_box( box_8002 );
	fn_0500_box( box_8003 );
	fn_0500_box( box_8004 );
	fn_0500_box( box_8005 );
	fn_0500_box( box_8006 );
	fn_0500_box( box_8007 );
	fn_0500_box( box_8008 );
	fn_0500_box( box_8009 );

	fn_0500_box( box_9000 );
	fn_0500_box( box_9001 );
	fn_0500_box( box_9002 );
	fn_0500_box( box_9003 );
	fn_0500_box( box_9004 );
	fn_0500_box( box_9005 );
	fn_0500_box( box_9006 );
	fn_0500_box( box_9007 );
	fn_0500_box( box_9008 );
	fn_0500_box( box_9009 );

/////////////////////////////////////////////////
///	SECTION ASSIGN

	fn_0500_section( section_0000 );
	fn_0500_section( section_1000 );
	fn_0500_section( section_2000 );
	fn_0500_section( section_3000 );
	fn_0500_section( section_4000 );
	fn_0500_section( section_5000 );
	fn_0500_section( section_6000 );
	fn_0500_section( section_7000 );
	fn_0500_section( section_8000 );
	fn_0500_section( section_9000 );

/////////////////////////////////////////////////
///	SELECTIVE ASSIGNMENTS

/////////////////////////////////////////////////

	media_0001.style.padding = 		'3mm';

	media_0010.style.padding = 		'3mm';
	media_0011.style.padding = 		'3mm';
	media_0012.style.padding = 		'3mm';
	media_0013.style.padding = 		'3mm';

	media_0020.style.padding = 		'7mm';
	media_0021.style.padding = 		'7mm';
	media_0022.style.padding = 		'7mm';
	media_0023.style.padding = 		'7mm';
	media_0024.style.padding = 		'7mm';
	media_0025.style.padding = 		'7mm';
	media_0026.style.padding = 		'7mm';
	media_0027.style.padding = 		'7mm';
	media_0028.style.padding = 		'7mm';
	media_0029.style.padding = 		'7mm';

	media_0041.style.border = 		'solid 2mm #00ABBA';	///solid,dotted,double,groove,
	media_0041.style.height = 		'47mm';
	media_0041.style.padding = 		'7mm';
	media_0041.style.width = 		'47mm';

/////////////////////////////////////////////////

	text_0000.style.fontSize = 		'14mm';
	text_0000.style.fontWeight = 		'1000';	///none,400,initial,bold,bolder
	text_0000.style.letterSpacing = 	'1mm';
	text_0000.style.fontVariantCaps = 	'small-caps';///small-caps,all-small-caps,petite-caps,all-petite-caps,unicase,titling-caps,textRendering,auto,optimizeSpeed,

	box_0000.style.padding = 		'5mm';

/////////////////////////////////////////////////

	box_1000.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1001.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1002.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1003.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1004.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1005.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1006.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1007.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1008.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_1009.style.width = 		'fit-content';	///window,fit-content,7mm,'', 

	link_1000.style.textDecoration = 	'none';	
	link_1001.style.textDecoration = 	'none';	
	link_1002.style.textDecoration = 	'none';	
	link_1003.style.textDecoration = 	'none';	
	link_1004.style.textDecoration = 	'none';	
	link_1005.style.textDecoration = 	'none';	
	link_1006.style.textDecoration = 	'none';	
	link_1007.style.textDecoration = 	'none';	
	link_1008.style.textDecoration = 	'none';	
	link_1009.style.textDecoration = 	'none';	

/////////////////////////////////////////////////

	text_2000.style.fontSize = 		'7mm';

/////////////////////////////////////////////////

	text_3000.style.fontSize = 		'7mm';
	box_3001.style.border = 		'';
	box_3001.style.background = 		'';
	box_3002.style.border = 		'';
	box_3002.style.background = 		'';

	box_3003.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_3004.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_3005.style.width = 		'fit-content';	///window,fit-content,7mm,'', 


	link_3000.style.textDecoration = 	'none';	
	link_3001.style.textDecoration = 	'none';	
	link_3002.style.textDecoration = 	'none';	
	link_3003.style.textDecoration = 	'none';	
	link_3004.style.textDecoration = 	'none';	
	link_3005.style.textDecoration = 	'none';	
	link_3006.style.textDecoration = 	'none';	
	link_3007.style.textDecoration = 	'none';	
	link_3008.style.textDecoration = 	'none';	
	link_3009.style.textDecoration = 	'none';	

/////////////////////////////////////////////////

	text_4000.style.fontSize = 		'7mm';

/////////////////////////////////////////////////

	text_5000.style.fontSize = 		'7mm';

	text_5001.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5002.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5003.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5004.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5005.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5006.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5007.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5008.style.textAlign = 		'left';	///start,end,left,right,center,justify
	text_5009.style.textAlign = 		'left';	///start,end,left,right,center,justify

/////////////////////////////////////////////////
///	6000
	text_6000.style.fontSize = 		'7mm';

/////////////////////////////////////////////////
///	7000
	text_7000.style.fontSize = 		'7mm';

/////////////////////////////////////////////////
///	8000
	box_8000.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8001.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8002.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8003.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8004.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8005.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8006.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8007.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8008.style.width = 		'fit-content';	///window,fit-content,7mm,'', 
	box_8009.style.width = 		'fit-content';	///window,fit-content,7mm,'', 

	link_8000.style.textDecoration = 	'none';	
	link_8001.style.textDecoration = 	'none';	
	link_8002.style.textDecoration = 	'none';	
	link_8003.style.textDecoration = 	'none';	
	link_8004.style.textDecoration = 	'none';	
	link_8005.style.textDecoration = 	'none';	
	link_8006.style.textDecoration = 	'none';	
	link_8007.style.textDecoration = 	'none';	
	link_8008.style.textDecoration = 	'none';	
	link_8009.style.textDecoration = 	'none';	

/////////////////////////////////////////////////
///	9000
	text_9000.style.fontSize = 		'7mm';
	box_9001.style.border = 		'';
	box_9001.style.background = 		'';

/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0500.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
