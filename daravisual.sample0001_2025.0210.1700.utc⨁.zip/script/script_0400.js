/////////////////////////////////////////////////
///	SECTION 0000
///	BLANK

/////////////////////////////////////////////////
///	media_0040.setAttribute( 'src', data_0002.png_0000_0000.src );
///	for ( var i=0; i<500; i++ ){};
///	setTimeout( function(){ text_4000.innerHTML = '__COMPLETE_0__'; }, 1000 );

/////////////////////////////////////////////////
var x0_gallery = 0;
box_5001.addEventListener( 'click', 
function(  ){
	x0_gallery = 	x0_gallery -1;
	media_5002.setAttribute( 'src', data_0002.srcset[ x0_gallery ] );
	}, false );

box_5003.addEventListener( 'click', 
function(  ){
	x0_gallery = 	x0_gallery +1;
	media_5002.setAttribute( 'src', data_0002.srcset[ x0_gallery ] );
	}, false );

/*
/////////////////////////////////////////////////
document.addEventListener( 'DOMContentLoaded', 
function fn_0000_timer(){
	setTimeout( function(  ){
		text_4000.innerHTML = '__COMPLETE_0__';
		}, 1000 );
	}, );
*/
/*
/////////////////////////////////////////////////
function fn_0000_timer( x0, x1 ){
	setTimeout( function(  ){
		text_4000.innerHTML = x1;
		}, x0 );
};
*/
/*
/////////////////////////////////////////////////
media_0040.addEventListener( 'onclick', 
function fn_0001_media(  ){
	text_4000.innerHTML = '__COMPLETE__';
///	media_0041.setAttribute( 'src', data_0002.png_0000_0000.src );
	}, false );
*/
/*
/////////////////////////////////////////////////
document.addEventListener( 'DOMContentLoaded', 
function fn_0000_media(  ){
	media_0040.setAttribute( 'src', data_0002.png_0206_0000.src );
	}, false );
*/
/*
/////////////////////////////////////////////////
///	STARTO, LOADS ATTRIBUTES INTO HTML AFTER DOC FINISHES
document.addEventListener( 'DOMContentLoaded', 
function fn_0000(  ){
	var x0 = 		document.getElementById( 'html_text_3000' );
	var x1 = 		document.getElementById( 'html_text_3001' );
	x0.innerHTML = 		'__START_TEXT_3000__';
	x1.innerHTML = 		'__START_TEXT_3001__';
	document.getElementById( 'html_text_3000' ).textContent = 	'_NEWTEXT_text_3000';
	document.getElementById( 'html_text_3001' ).textContent = 	'_NEWTEXT_text_3001';
	});
*/


/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0400.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
