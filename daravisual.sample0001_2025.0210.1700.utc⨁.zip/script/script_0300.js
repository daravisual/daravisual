/////////////////////////////////////////////////
///	SECTION 0000
///	ATTRIBUTES, ALL SECTIONS

/////////////////////////////////////////////////
///	AUDIO ATTRIBUTES
///	CONNECT FROM (data_0002), 
function fn_0300_audio_attr( x0, y0 ){
	x0.setAttribute( 'alt', 		y0.alt );
	x0.setAttribute( 'fetchpriority', 	y0.fetchpriority );
	x0.setAttribute( 'height', 		y0.height );
	x0.setAttribute( 'referrerpolicy', 	y0.referrerpolicy );
	x0.setAttribute( 'rel', 		y0.rel );
	x0.setAttribute( 'src', 		y0.src );
///	x0.setAttribute( 'tabindex', 		y0.tabindex );
	x0.setAttribute( 'title', 		y0.title );
	x0.setAttribute( 'width', 		y0.width );
	delete ( x0, y0 );
	};


/////////////////////////////////////////////////
///	LINK ATTRIBUTES
///	CONNECT FROM (data_0001), 
function fn_0300_link_attr( x0, y0, x1 ){
	x0.setAttribute( 'alt', 		y0.alt );
	x0.setAttribute( 'fetchpriority', 	y0.fetchpriority );
	x0.setAttribute( 'href', 		y0.href );
	x0.setAttribute( 'referrerpolicy', 	y0.referrerpolicy );
	x0.setAttribute( 'rel', 		y0.rel );
///	x0.setAttribute( 'tabindex', 		y0.tabindex );
	x0.setAttribute( 'title', 		y0.title );
	x1.innerHTML = 				y0.title;
	delete ( x0, y0, x1 );
	};


/////////////////////////////////////////////////
///	MEDIA ATTRIBUTES
///	CONNECT FROM (data_0002), 
function fn_0300_media_attr( x0, y0 ){
	x0.setAttribute( 'alt', 		y0.alt );
	x0.setAttribute( 'fetchpriority', 	y0.fetchpriority );
	x0.setAttribute( 'height', 		y0.height );
	x0.setAttribute( 'referrerpolicy', 	y0.referrerpolicy );
	x0.setAttribute( 'rel', 		y0.rel );
	x0.setAttribute( 'src', 		y0.src );
///	x0.setAttribute( 'tabindex', 		y0.tabindex );
	x0.setAttribute( 'title', 		y0.title );
	x0.setAttribute( 'width', 		y0.width );
	delete ( x0, y0 );
	};


/////////////////////////////////////////////////
///	TEXT ATTRIBUTES
///	CONNECT FROM (data_0003), 
function fn_0300_text_attr( x0, y0 ){
	x0.innerHTML = 		y0[0]; /// OPERATIONAL
///	x0.innerHTML = 		y0[3]; /// DIAGNOSTIC
	delete ( x0, y0 );
	};


/////////////////////////////////////////////////
///	VIDEO ATTRIBUTES
///	CONNECT FROM (data_0002), 
function fn_0300_video_attr( x0, y0 ){
	x0.setAttribute( 'alt', 		y0.alt );
	x0.setAttribute( 'fetchpriority', 	y0.fetchpriority );
	x0.setAttribute( 'height', 		y0.height );
	x0.setAttribute( 'referrerpolicy', 	y0.referrerpolicy );
	x0.setAttribute( 'rel', 		y0.rel );
	x0.setAttribute( 'src', 		y0.src );
///	x0.setAttribute( 'tabindex', 		y0.tabindex );
	x0.setAttribute( 'title', 		y0.title );
	x0.setAttribute( 'width', 		y0.width );
	delete ( x0, y0 );
	};


/////////////////////////////////////////////////
///	DETAILS, ALL, 
/*
	details_0000.setAttribute( 'name', 	'details_name' );
	details_1000.setAttribute( 'name', 	'details_name' );
	details_2000.setAttribute( 'name', 	'details_name' );
	details_3000.setAttribute( 'name', 	'details_name' );
	details_4000.setAttribute( 'name', 	'details_name' );
	details_5000.setAttribute( 'name', 	'details_name' );
	details_6000.setAttribute( 'name', 	'details_name' );
	details_7000.setAttribute( 'name', 	'details_name' );
	details_8000.setAttribute( 'name', 	'details_name' );
	details_9000.setAttribute( 'name', 	'details_name' );
*/
	details_0000.setAttribute( 'open', 	'true' );
	details_1000.setAttribute( 'open', 	'true' );
	details_2000.setAttribute( 'open', 	'true' );
	details_3000.setAttribute( 'open', 	'true' );
	details_4000.setAttribute( 'open', 	'true' );
	details_5000.setAttribute( 'open', 	'true' );
	details_6000.setAttribute( 'open', 	'true' );
	details_7000.setAttribute( 'open', 	'true' );
	details_8000.setAttribute( 'open', 	'true' );
	details_9000.setAttribute( 'open', 	'true' );

	section_0000.setAttribute( 'tag', 	'badges' );
	section_1000.setAttribute( 'tag', 	'banner' );
	section_2000.setAttribute( 'tag', 	'services' );
	section_3000.setAttribute( 'tag', 	'about' );
	section_4000.setAttribute( 'tag', 	'getaquote' );
	section_5000.setAttribute( 'tag', 	'gallery' );
	section_6000.setAttribute( 'tag', 	'section6000' );
	section_7000.setAttribute( 'tag', 	'section7000' );
	section_8000.setAttribute( 'tag', 	'section8000' );
	section_9000.setAttribute( 'tag', 	'notice' );

/////////////////////////////////////////////////
///	0000, & MEDIA, 

	fn_0300_media_attr( media_0000, data_0002.png_0208_0003 );
	fn_0300_media_attr( media_0001, data_0002.png_0208_0003 );
	fn_0300_media_attr( media_0002, data_0002.png_0208_0000 );
	fn_0300_media_attr( media_0003, data_0002.png_0208_0001 );
	fn_0300_media_attr( media_0004, data_0002.png_0208_0002 );
	fn_0300_media_attr( media_0005, data_0002.png_0208_0005 );
	fn_0300_media_attr( media_0006, data_0002.png_0208_0004 );
/*
///	fn_0300_media_attr( media_0007, data_0002.png_0000_0000 );
///	fn_0300_media_attr( media_0008, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0009, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0010, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0011, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0012, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0013, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0014, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0015, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0016, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0017, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0018, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0019, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0020, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0021, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0022, data_0002.png_0000_0000 );
	fn_0300_media_attr( media_0023, data_0002.png_0000_0000 );
*/
/////////////////////////////////////////////////
///	1000
/*
	fn_0300_link_attr( link_1000, data_0001.link_0000, text_1000 );
	fn_0300_link_attr( link_1001, data_0001.link_0001, text_1001 );
	fn_0300_link_attr( link_1002, data_0001.link_0002, text_1002 );
	fn_0300_link_attr( link_1003, data_0001.link_0003, text_1003 );
	fn_0300_link_attr( link_1004, data_0001.link_0004, text_1004 );
	fn_0300_link_attr( link_1005, data_0001.link_0005, text_1005 );
	fn_0300_link_attr( link_1006, data_0001.link_0006, text_1006 );
	fn_0300_link_attr( link_1007, data_0001.link_0007, text_1007 );
	fn_0300_link_attr( link_1008, data_0001.link_0008, text_1008 );
	fn_0300_link_attr( link_1009, data_0001.link_0009, text_1009 );
*/
/////////////////////////////////////////////////
///	2000
/*
	fn_0300_link_attr( link_2000, data_0001.link_0000, text_2000 );
	fn_0300_link_attr( link_2001, data_0001.link_0001, text_2001 );
	fn_0300_link_attr( link_2002, data_0001.link_0002, text_2002 );
	fn_0300_link_attr( link_2003, data_0001.link_0003, text_2003 );
	fn_0300_link_attr( link_2004, data_0001.link_0004, text_2004 );
	fn_0300_link_attr( link_2005, data_0001.link_0005, text_2005 );
	fn_0300_link_attr( link_2006, data_0001.link_0006, text_2006 );
	fn_0300_link_attr( link_2007, data_0001.link_0007, text_2007 );
	fn_0300_link_attr( link_2008, data_0001.link_0008, text_2008 );
	fn_0300_link_attr( link_2009, data_0001.link_0009, text_2009 );
*/
/////////////////////////////////////////////////
///	3000
/*
	fn_0300_link_attr( link_3000, data_0001.link_0000, text_3000 );
	fn_0300_link_attr( link_3001, data_0001.link_0001, text_3001 );
	fn_0300_link_attr( link_3002, data_0001.link_0002, text_3002 );
*/
	fn_0300_link_attr( link_3003, data_0001.link_0008, text_3003 );
/*
	fn_0300_link_attr( link_3004, data_0001.link_0004, text_3004 );
	fn_0300_link_attr( link_3005, data_0001.link_0005, text_3005 );
	fn_0300_link_attr( link_3006, data_0001.link_0006, text_3006 );
	fn_0300_link_attr( link_3007, data_0001.link_0007, text_3007 );
	fn_0300_link_attr( link_3008, data_0001.link_0008, text_3008 );
	fn_0300_link_attr( link_3009, data_0001.link_0009, text_3009 );
*/
	fn_0300_audio_attr( audio_0000, data_0002.wav_0205_0000 );
	fn_0300_video_attr( video_0000, data_0002.mov_0205_0000 );

/////////////////////////////////////////////////
///	4000
	fn_0300_link_attr( link_4001, data_0001.link_0009, text_4001 );
	fn_0300_link_attr( link_4002, data_0001.link_0008, text_4002 );
	fn_0300_link_attr( link_4003, data_0001.link_0004, text_4003 );

/////////////////////////////////////////////////
///	5000
	fn_0300_link_attr( link_5005, data_0001.link_0000, text_5005 );

///	media_5001.setAttribute( 'src', './media/png_0000_0000.png' );
///	fn_0300_media_attr( media_5001, data_0002.png_0207_0000 );
///	fn_0300_media_attr( media_5002, data_0002.png_0000_0000 );
///	fn_0300_media_attr( media_5003, data_0002.png_0207_0001 );

/////////////////////////////////////////////////
///	6000	NOT ASSIGNED

/////////////////////////////////////////////////
///	7000	NOT ASSIGNED

/////////////////////////////////////////////////
///	8000	NOT ASSIGNED

/////////////////////////////////////////////////
///	9000
	fn_0300_link_attr( link_9000, data_0001.link_0000, text_9000 );
	fn_0300_link_attr( link_9001, data_0001.link_0001, text_9001 );
	fn_0300_link_attr( link_9002, data_0001.link_0002, text_9002 );
	fn_0300_link_attr( link_9003, data_0001.link_0003, text_9003 );
	fn_0300_link_attr( link_9004, data_0001.link_0004, text_9004 );
	fn_0300_link_attr( link_9005, data_0001.link_0005, text_9005 );
	fn_0300_link_attr( link_9006, data_0001.link_0006, text_9006 );
	fn_0300_link_attr( link_9007, data_0001.link_0007, text_9007 );
	fn_0300_link_attr( link_9008, data_0001.link_0008, text_9008 );
	fn_0300_link_attr( link_9009, data_0001.link_0009, text_9009 );

/////////////////////////////////////////////////
///	TEXT ALL

	fn_0300_text_attr( text_0000, data_0003.text_0000 );
	fn_0300_text_attr( text_0001, data_0003.text_0001 );
	fn_0300_text_attr( text_0002, data_0003.text_0002 );
	fn_0300_text_attr( text_0003, data_0003.text_0003 );
	fn_0300_text_attr( text_0004, data_0003.text_0004 );
	fn_0300_text_attr( text_0005, data_0003.text_0005 );
	fn_0300_text_attr( text_0006, data_0003.text_0006 );
	fn_0300_text_attr( text_0007, data_0003.text_0007 );
	fn_0300_text_attr( text_0008, data_0003.text_0008 );
	fn_0300_text_attr( text_0009, data_0003.text_0009 );
	fn_0300_text_attr( text_0010, data_0003.text_0010 );
	fn_0300_text_attr( text_0011, data_0003.text_0011 );
	fn_0300_text_attr( text_0012, data_0003.text_0012 );
	fn_0300_text_attr( text_0013, data_0003.text_0013 );
	fn_0300_text_attr( text_0014, data_0003.text_0014 );
	fn_0300_text_attr( text_0015, data_0003.text_0015 );
	fn_0300_text_attr( text_0016, data_0003.text_0016 );
	fn_0300_text_attr( text_0017, data_0003.text_0017 );
	fn_0300_text_attr( text_0018, data_0003.text_0018 );
	fn_0300_text_attr( text_0019, data_0003.text_0019 );
	fn_0300_text_attr( text_0020, data_0003.text_0020 );
	fn_0300_text_attr( text_0021, data_0003.text_0021 );
	fn_0300_text_attr( text_0022, data_0003.text_0022 );
	fn_0300_text_attr( text_0023, data_0003.text_0023 );

	fn_0300_text_attr( text_1000, data_0003.text_1000 );
	fn_0300_text_attr( text_1001, data_0003.text_1001 );
	fn_0300_text_attr( text_1002, data_0003.text_1002 );
	fn_0300_text_attr( text_1003, data_0003.text_1003 );
	fn_0300_text_attr( text_1004, data_0003.text_1004 );
	fn_0300_text_attr( text_1005, data_0003.text_1005 );
	fn_0300_text_attr( text_1006, data_0003.text_1006 );
	fn_0300_text_attr( text_1007, data_0003.text_1007 );
	fn_0300_text_attr( text_1008, data_0003.text_1008 );
	fn_0300_text_attr( text_1009, data_0003.text_1009 );
	fn_0300_text_attr( text_1010, data_0003.text_1010 );
	fn_0300_text_attr( text_1011, data_0003.text_1011 );
	fn_0300_text_attr( text_1012, data_0003.text_1012 );
	fn_0300_text_attr( text_1013, data_0003.text_1013 );
	fn_0300_text_attr( text_1014, data_0003.text_1014 );
	fn_0300_text_attr( text_1015, data_0003.text_1015 );
	fn_0300_text_attr( text_1016, data_0003.text_1016 );
	fn_0300_text_attr( text_1017, data_0003.text_1017 );
	fn_0300_text_attr( text_1018, data_0003.text_1018 );
	fn_0300_text_attr( text_1019, data_0003.text_1019 );
	fn_0300_text_attr( text_1020, data_0003.text_1020 );
	fn_0300_text_attr( text_1021, data_0003.text_1021 );
	fn_0300_text_attr( text_1022, data_0003.text_1022 );
	fn_0300_text_attr( text_1023, data_0003.text_1023 );

	fn_0300_text_attr( text_2000, data_0003.text_2000 );
	fn_0300_text_attr( text_2001, data_0003.text_2001 );
	fn_0300_text_attr( text_2002, data_0003.text_2002 );
	fn_0300_text_attr( text_2003, data_0003.text_2003 );
	fn_0300_text_attr( text_2004, data_0003.text_2004 );
	fn_0300_text_attr( text_2005, data_0003.text_2005 );
	fn_0300_text_attr( text_2006, data_0003.text_2006 );
	fn_0300_text_attr( text_2007, data_0003.text_2007 );
	fn_0300_text_attr( text_2008, data_0003.text_2008 );
	fn_0300_text_attr( text_2009, data_0003.text_2009 );
	fn_0300_text_attr( text_2010, data_0003.text_2010 );
	fn_0300_text_attr( text_2011, data_0003.text_2011 );
	fn_0300_text_attr( text_2012, data_0003.text_2012 );
	fn_0300_text_attr( text_2013, data_0003.text_2013 );
	fn_0300_text_attr( text_2014, data_0003.text_2014 );
	fn_0300_text_attr( text_2015, data_0003.text_2015 );
	fn_0300_text_attr( text_2016, data_0003.text_2016 );
	fn_0300_text_attr( text_2017, data_0003.text_2017 );
	fn_0300_text_attr( text_2018, data_0003.text_2018 );
	fn_0300_text_attr( text_2019, data_0003.text_2019 );
	fn_0300_text_attr( text_2020, data_0003.text_2020 );
	fn_0300_text_attr( text_2021, data_0003.text_2021 );
	fn_0300_text_attr( text_2022, data_0003.text_2022 );
	fn_0300_text_attr( text_2023, data_0003.text_2023 );

	fn_0300_text_attr( text_3000, data_0003.text_3000 );
	fn_0300_text_attr( text_3001, data_0003.text_3001 );
	fn_0300_text_attr( text_3002, data_0003.text_3002 );
	fn_0300_text_attr( text_3003, data_0003.text_3003 );
	fn_0300_text_attr( text_3004, data_0003.text_3004 );
	fn_0300_text_attr( text_3005, data_0003.text_3005 );
	fn_0300_text_attr( text_3006, data_0003.text_3006 );
	fn_0300_text_attr( text_3007, data_0003.text_3007 );
	fn_0300_text_attr( text_3008, data_0003.text_3008 );
	fn_0300_text_attr( text_3009, data_0003.text_3009 );
	fn_0300_text_attr( text_3010, data_0003.text_3010 );
	fn_0300_text_attr( text_3011, data_0003.text_3011 );
	fn_0300_text_attr( text_3012, data_0003.text_3012 );
	fn_0300_text_attr( text_3013, data_0003.text_3013 );
	fn_0300_text_attr( text_3014, data_0003.text_3014 );
	fn_0300_text_attr( text_3015, data_0003.text_3015 );
	fn_0300_text_attr( text_3016, data_0003.text_3016 );
	fn_0300_text_attr( text_3017, data_0003.text_3017 );
	fn_0300_text_attr( text_3018, data_0003.text_3018 );
	fn_0300_text_attr( text_3019, data_0003.text_3019 );
	fn_0300_text_attr( text_3020, data_0003.text_3020 );
	fn_0300_text_attr( text_3021, data_0003.text_3021 );
	fn_0300_text_attr( text_3022, data_0003.text_3022 );
	fn_0300_text_attr( text_3023, data_0003.text_3023 );

	fn_0300_text_attr( text_4000, data_0003.text_4000 );
	fn_0300_text_attr( text_4001, data_0003.text_4001 );
	fn_0300_text_attr( text_4002, data_0003.text_4002 );
	fn_0300_text_attr( text_4003, data_0003.text_4003 );
	fn_0300_text_attr( text_4004, data_0003.text_4004 );
	fn_0300_text_attr( text_4005, data_0003.text_4005 );
	fn_0300_text_attr( text_4006, data_0003.text_4006 );
	fn_0300_text_attr( text_4007, data_0003.text_4007 );
	fn_0300_text_attr( text_4008, data_0003.text_4008 );
	fn_0300_text_attr( text_4009, data_0003.text_4009 );
	fn_0300_text_attr( text_4010, data_0003.text_4010 );
	fn_0300_text_attr( text_4011, data_0003.text_4011 );
	fn_0300_text_attr( text_4012, data_0003.text_4012 );
	fn_0300_text_attr( text_4013, data_0003.text_4013 );
	fn_0300_text_attr( text_4014, data_0003.text_4014 );
	fn_0300_text_attr( text_4015, data_0003.text_4015 );
	fn_0300_text_attr( text_4016, data_0003.text_4016 );
	fn_0300_text_attr( text_4017, data_0003.text_4017 );
	fn_0300_text_attr( text_4018, data_0003.text_4018 );
	fn_0300_text_attr( text_4019, data_0003.text_4019 );
	fn_0300_text_attr( text_4020, data_0003.text_4020 );
	fn_0300_text_attr( text_4021, data_0003.text_4021 );
	fn_0300_text_attr( text_4022, data_0003.text_4022 );
	fn_0300_text_attr( text_4023, data_0003.text_4023 );

	fn_0300_text_attr( text_5000, data_0003.text_5000 );
	fn_0300_text_attr( text_5001, data_0003.text_5001 );
	fn_0300_text_attr( text_5003, data_0003.text_5003 );
	fn_0300_text_attr( text_5004, data_0003.text_5004 );
	fn_0300_text_attr( text_5005, data_0003.text_5005 );
	fn_0300_text_attr( text_5006, data_0003.text_5006 );
	fn_0300_text_attr( text_5007, data_0003.text_5007 );
	fn_0300_text_attr( text_5008, data_0003.text_5008 );
	fn_0300_text_attr( text_5009, data_0003.text_5009 );
	fn_0300_text_attr( text_5010, data_0003.text_5010 );
	fn_0300_text_attr( text_5011, data_0003.text_5011 );
	fn_0300_text_attr( text_5012, data_0003.text_5012 );
	fn_0300_text_attr( text_5013, data_0003.text_5013 );
	fn_0300_text_attr( text_5014, data_0003.text_5014 );
	fn_0300_text_attr( text_5015, data_0003.text_5015 );
	fn_0300_text_attr( text_5016, data_0003.text_5016 );
	fn_0300_text_attr( text_5017, data_0003.text_5017 );
	fn_0300_text_attr( text_5018, data_0003.text_5018 );
	fn_0300_text_attr( text_5019, data_0003.text_5019 );
	fn_0300_text_attr( text_5020, data_0003.text_5020 );
	fn_0300_text_attr( text_5021, data_0003.text_5021 );
	fn_0300_text_attr( text_5022, data_0003.text_5022 );
	fn_0300_text_attr( text_5023, data_0003.text_5023 );

	fn_0300_text_attr( text_6000, data_0003.text_6000 );
	fn_0300_text_attr( text_6001, data_0003.text_6001 );
	fn_0300_text_attr( text_6002, data_0003.text_6002 );
	fn_0300_text_attr( text_6003, data_0003.text_6003 );
	fn_0300_text_attr( text_6004, data_0003.text_6004 );
	fn_0300_text_attr( text_6005, data_0003.text_6005 );
	fn_0300_text_attr( text_6006, data_0003.text_6006 );
	fn_0300_text_attr( text_6007, data_0003.text_6007 );
	fn_0300_text_attr( text_6008, data_0003.text_6008 );
	fn_0300_text_attr( text_6009, data_0003.text_6009 );
	fn_0300_text_attr( text_6010, data_0003.text_6010 );
	fn_0300_text_attr( text_6011, data_0003.text_6011 );
	fn_0300_text_attr( text_6012, data_0003.text_6012 );
	fn_0300_text_attr( text_6013, data_0003.text_6013 );
	fn_0300_text_attr( text_6014, data_0003.text_6014 );
	fn_0300_text_attr( text_6015, data_0003.text_6015 );
	fn_0300_text_attr( text_6016, data_0003.text_6016 );
	fn_0300_text_attr( text_6017, data_0003.text_6017 );
	fn_0300_text_attr( text_6018, data_0003.text_6018 );
	fn_0300_text_attr( text_6019, data_0003.text_6019 );
	fn_0300_text_attr( text_6020, data_0003.text_6020 );
	fn_0300_text_attr( text_6021, data_0003.text_6021 );
	fn_0300_text_attr( text_6022, data_0003.text_6022 );
	fn_0300_text_attr( text_6023, data_0003.text_6023 );

	fn_0300_text_attr( text_7000, data_0003.text_7000 );
	fn_0300_text_attr( text_7001, data_0003.text_7001 );
	fn_0300_text_attr( text_7002, data_0003.text_7002 );
	fn_0300_text_attr( text_7003, data_0003.text_7003 );
	fn_0300_text_attr( text_7004, data_0003.text_7004 );
	fn_0300_text_attr( text_7005, data_0003.text_7005 );
	fn_0300_text_attr( text_7006, data_0003.text_7006 );
	fn_0300_text_attr( text_7007, data_0003.text_7007 );
	fn_0300_text_attr( text_7008, data_0003.text_7008 );
	fn_0300_text_attr( text_7009, data_0003.text_7009 );
	fn_0300_text_attr( text_7010, data_0003.text_7010 );
	fn_0300_text_attr( text_7011, data_0003.text_7011 );
	fn_0300_text_attr( text_7012, data_0003.text_7012 );
	fn_0300_text_attr( text_7013, data_0003.text_7013 );
	fn_0300_text_attr( text_7014, data_0003.text_7014 );
	fn_0300_text_attr( text_7015, data_0003.text_7015 );
	fn_0300_text_attr( text_7016, data_0003.text_7016 );
	fn_0300_text_attr( text_7017, data_0003.text_7017 );
	fn_0300_text_attr( text_7018, data_0003.text_7018 );
	fn_0300_text_attr( text_7019, data_0003.text_7019 );
	fn_0300_text_attr( text_7020, data_0003.text_7020 );
	fn_0300_text_attr( text_7021, data_0003.text_7021 );
	fn_0300_text_attr( text_7022, data_0003.text_7022 );
	fn_0300_text_attr( text_7023, data_0003.text_7023 );

	fn_0300_text_attr( text_8000, data_0003.text_8000 );
	fn_0300_text_attr( text_8001, data_0003.text_8001 );
	fn_0300_text_attr( text_8002, data_0003.text_8002 );
	fn_0300_text_attr( text_8003, data_0003.text_8003 );
	fn_0300_text_attr( text_8004, data_0003.text_8004 );
	fn_0300_text_attr( text_8005, data_0003.text_8005 );
	fn_0300_text_attr( text_8006, data_0003.text_8006 );
	fn_0300_text_attr( text_8007, data_0003.text_8007 );
	fn_0300_text_attr( text_8008, data_0003.text_8008 );
	fn_0300_text_attr( text_8009, data_0003.text_8009 );
	fn_0300_text_attr( text_8010, data_0003.text_8010 );
	fn_0300_text_attr( text_8011, data_0003.text_8011 );
	fn_0300_text_attr( text_8012, data_0003.text_8012 );
	fn_0300_text_attr( text_8013, data_0003.text_8013 );
	fn_0300_text_attr( text_8014, data_0003.text_8014 );
	fn_0300_text_attr( text_8015, data_0003.text_8015 );
	fn_0300_text_attr( text_8016, data_0003.text_8016 );
	fn_0300_text_attr( text_8017, data_0003.text_8017 );
	fn_0300_text_attr( text_8018, data_0003.text_8018 );
	fn_0300_text_attr( text_8019, data_0003.text_8019 );
	fn_0300_text_attr( text_8020, data_0003.text_8020 );
	fn_0300_text_attr( text_8021, data_0003.text_8021 );
	fn_0300_text_attr( text_8022, data_0003.text_8022 );
	fn_0300_text_attr( text_8023, data_0003.text_8023 );

	fn_0300_text_attr( text_9000, data_0003.text_9000 );
	fn_0300_text_attr( text_9001, data_0003.text_9001 );
	fn_0300_text_attr( text_9002, data_0003.text_9002 );
	fn_0300_text_attr( text_9003, data_0003.text_9003 );
	fn_0300_text_attr( text_9004, data_0003.text_9004 );
	fn_0300_text_attr( text_9005, data_0003.text_9005 );
	fn_0300_text_attr( text_9006, data_0003.text_9006 );
	fn_0300_text_attr( text_9007, data_0003.text_9007 );
	fn_0300_text_attr( text_9008, data_0003.text_9008 );
	fn_0300_text_attr( text_9009, data_0003.text_9009 );
	fn_0300_text_attr( text_9010, data_0003.text_9010 );
	fn_0300_text_attr( text_9011, data_0003.text_9011 );
	fn_0300_text_attr( text_9012, data_0003.text_9012 );
	fn_0300_text_attr( text_9013, data_0003.text_9013 );
	fn_0300_text_attr( text_9014, data_0003.text_9014 );
	fn_0300_text_attr( text_9015, data_0003.text_9015 );
	fn_0300_text_attr( text_9016, data_0003.text_9016 );
	fn_0300_text_attr( text_9017, data_0003.text_9017 );
	fn_0300_text_attr( text_9018, data_0003.text_9018 );
	fn_0300_text_attr( text_9019, data_0003.text_9019 );
	fn_0300_text_attr( text_9020, data_0003.text_9020 );
	fn_0300_text_attr( text_9021, data_0003.text_9021 );
	fn_0300_text_attr( text_9022, data_0003.text_9022 );
	fn_0300_text_attr( text_9023, data_0003.text_9023 );

/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0300.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
