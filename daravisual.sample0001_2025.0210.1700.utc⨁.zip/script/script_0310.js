/////////////////////////////////////////////////
///	SECTION 1000

/*
///	TEST BUTTONS & INPUT BOX
/////////////////////////////////////////////////

	section_1000.append( label_0000 );
	section_1000.append( button_0000 );
	section_1000.append( br_0001 );

	section_1000.append( label_0001 );
	section_1000.append( button_0001 );
	section_1000.append( br_0002 );

	section_1000.append( label_0002 );
	section_1000.append( button_0002 );
	section_1000.append( br_0003 );

	label_0000.append( input_0000 );
	label_0001.append( input_0001 );
	label_0002.append( input_0002 );

/////////////////////////////////////////////////
function fn_0000_update_inputToText(){
	text_1000.innerHTML = 	input_0000.value;
	text_1001.innerHTML = 	input_0001.value;
	text_1002.innerHTML = 	input_0002.value;
};


///	input_0000.setAttribute( 'accept', 		true );
///	input_0000.setAttribute( 'alt', 		'__ALT__' );
///	input_0000.setAttribute( 'autocomplete', 	'' );
///	input_0000.setAttribute( 'checked', 		false );
///	input_0000.setAttribute( 'dirname', 		'' );
///	input_0000.setAttribute( 'disabled', 		false );
///	input_0000.setAttribute( 'form', 		'___' );
///	input_0000.setAttribute( 'formaction', 		'___' );
///	input_0000.setAttribute( 'formenctype', 	'___' );
///	input_0000.setAttribute( 'formmethod', 		'___' );
///	input_0000.setAttribute( 'formnovalidate', 	'___' );
///	input_0000.setAttribute( 'formtarget', 		'___' );
///	input_0000.setAttribute( 'height', 		'27mm' );
///	input_0000.setAttribute( 'id', 			'___' );
///	input_0000.setAttribute( 'list', 		'' );
///	input_0000.setAttribute( 'max', 		'___' );
///	input_0000.setAttribute( 'maxlength', 		10 );
///	input_0000.setAttribute( 'min', 		'___' );
///	input_0000.setAttribute( 'minlength', 		0 );
///	input_0000.setAttribute( 'multiple', 		'___' );
///	input_0000.setAttribute( 'name', 		'input_0000' );	
///	input_0000.setAttribute( 'pattern', 		'' );
	input_0000.setAttribute( 'placeholder', 	'__input_0000__' );
///	input_0000.setAttribute( 'popovertarget', 	'___' );
///	input_0000.setAttribute( 'popovertargetaction', '___' );
///	input_0000.setAttribute( 'readonly', 		false );
///	input_0000.setAttribute( 'required', 		true );
///	input_0000.setAttribute( 'size', 		'' );
///	input_0000.setAttribute( 'src', 		'___' );
///	input_0000.setAttribute( 'step', 		'___' );
	input_0000.setAttribute( 'type', 		'text' );
	input_0000.setAttribute( 'value', 		'__input_0000__' );
///	input_0000.setAttribute( 'width', 		'77mm' );
	input_0000.setAttribute( 'title', 		'__TITLE_input__' );

	input_0001.setAttribute( 'placeholder', 	'__input_0001__' );
	input_0001.setAttribute( 'title', 		'__TITLE_input__' );
	input_0001.setAttribute( 'value', 		'__input_0001__' );

	input_0002.setAttribute( 'placeholder', 	'__input_0002__' );
	input_0002.setAttribute( 'title', 		'__TITLE_input__' );
	input_0002.setAttribute( 'value', 		'__input_0002__' );

/////////////////////////////////////////////////
///	DEFINITELY `ONSUBMIT` BUTTON ATTR, 
	button_0000.setAttribute( 'onsubmit', 		fn_0000_update_inputToText() );
	button_0001.setAttribute( 'onsubmit', 		fn_0000_update_inputToText() );
	button_0002.setAttribute( 'onsubmit', 		fn_0000_update_inputToText() );

///	DOES NOT FUNCTION
///	button_0000.setAttribute( 'popovertarget', 	text_1003 );
///	button_0000.setAttribute( 'popovertargetaction','toggle' );

/////////////////////////////////////////////////

	button_0000.setAttribute( 'title', 		'__button_0000__' );
	button_0001.setAttribute( 'title', 		'__button_0001__' );
	button_0002.setAttribute( 'title', 		'__button_0002__' );

	button_0000.innerHTML = 		data_0003.button_0000[0];
	button_0001.innerHTML = 		data_0003.button_0001[0];
	button_0002.innerHTML = 		data_0003.button_0002[0];

	

/////////////////////////////////////////////////
///	ADD LISTENER, DIRECT INPUT UPDATES, FROM & TO
function fn_0000_onclick(){
	button_0000.addEventListener( 'onsubmit', fn_0000_update_inputToText() );
};
///	fn_0000_onclick();

*/
/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0310.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
