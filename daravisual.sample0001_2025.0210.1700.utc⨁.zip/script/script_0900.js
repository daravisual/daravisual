/////////////////////////////////////////////////
///	SECTION 0000
///	DISPLAY NONE, ALL, 

/////////////////////////////////////////////////

	details_0000.style.display = 		'none';
	details_1000.style.display = 		'none';
	///
	details_6000.style.display = 		'none';
	details_7000.style.display = 		'none';
	details_8000.style.display = 		'none';
/*
	///
	link_1001.style.display = 		'none';
	link_1002.style.display = 		'none';
	link_1003.style.display = 		'none';
	link_1004.style.display = 		'none';
	link_1005.style.display = 		'none';
	link_1006.style.display = 		'none';
	link_1007.style.display = 		'none';
	link_1008.style.display = 		'none';
	link_1009.style.display = 		'none';

	///
	link_2004.style.display = 		'none';
	link_2005.style.display = 		'none';
	link_2006.style.display = 		'none';
	link_2007.style.display = 		'none';
	link_2008.style.display = 		'none';
	link_2009.style.display = 		'none';

	///
	link_3004.style.display = 		'none';
	link_3005.style.display = 		'none';
	link_3006.style.display = 		'none';
	link_3007.style.display = 		'none';
	link_3008.style.display = 		'none';
	link_3009.style.display = 		'none';

	///
	link_4004.style.display = 		'none';
	link_4005.style.display = 		'none';
	link_4006.style.display = 		'none';
	link_4007.style.display = 		'none';
	link_4008.style.display = 		'none';
	link_4009.style.display = 		'none';

	///
	link_5006.style.display = 		'none';
	link_5007.style.display = 		'none';
	link_5008.style.display = 		'none';
	link_5009.style.display = 		'none';

	section_6000.style.display = 		'none';
	section_7000.style.display = 		'none';
	section_8000.style.display = 		'none';

	///
	link_9005.style.display = 		'none';
	link_9006.style.display = 		'none';
	link_9007.style.display = 		'none';
*/
/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	script_diagnostic_0900.style.display = 		'none';

/////////////////////////////////////////////////
///	Copyright 2024 David Rain, BSD-3, /*******/
///
///Redistribution and use in source and binary forms, with or 
///without modification, are permitted provided that the 
///following conditions are met:
///
///	1. Redistributions of source code must retain the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer.
///
///	2. Redistributions in binary form must reproduce the 
///	above copyright notice, this list of conditions and 
///	the following disclaimer in the documentation and/or 
///	other materials provided with the distribution.
///
///	3. Neither the name of the copyright holder nor the 
///	names of its contributors may be used to endorse or 
///	promote products derived from this software without 
///	specific prior written permission.
///
///THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
///'AS IS' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
///LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
///FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
///COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
///INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
///BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
///LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
///CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
///LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
///ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
///POSSIBILITY OF SUCH DAMAGE.
////////////////////////////////////////////////
