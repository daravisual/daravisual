
/////////////////////////////////////////////////
///	DATA: MEDIA

/////////////////////////////////////////////////

var data_0002 = {

/////////////////////////////////////////////////
__FILENAME__:{
///__DATE__,__DESC__,__ELM__,__FILE_TYPE__,__FILENAME__,__TITLE__,__FILE_GROUP__
alt:		'__DESC__', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'__DATE__.utc⨁', 
decoding:	'', 
desc:		'__DESC__', 
elm:		'__ELM__', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/__FILENAME__.__FILE_TYPE__', 
srcset:[
		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	], 
title:		'__TITLE__', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/__FILE_TYPE__', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/__FILENAME__.__FILE_TYPE__', 
		mime_type:	'image/png', 
		title:		'__TITLE__', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__',
	content_html:	'<p>__DESC__</p>', 
	content_text:	'__DESC__', 
	date_modified:	'__DATE__.utc⨁', 
	date_published:	'__DATE__.utc⨁', 
	external_url:	'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	id:		'__FILENAME__', 
	image:		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	language:	'en-US', 
	summary:	'__DESC__', 
	tags:		[ '__TITLE__', '__FILE_GROUP__', '__FILE_TYPE__', ], 
	title:		'__TITLE__', 
	url:		'https://media.oionlta.app/media/__FILENAME__.__FILE_TYPE__', 
	}, 

},



/////////////////////////////////////////////////
mov_0205_0000:{ 
alt:		'About Oion LTA', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'A short video about Oion Learning & Training Academy', 
elm:		'video', 
fetchpriority:	'low', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'true', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/mov_0205_0000.mov', 
srcset:[
	], 
title:		'About Oion LTA', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'video/mov', 
usemap:		'', 
width:		'window', 
wci:{ 
	attachments:[ { 
		url:		'./media/mov_0205_0000.mov', 
		mime_type:	'video/mov', 
		title:		'About Oion LTA', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'https://media.oionlta.app/media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/mov_0205_0000/banner_image.png',
	content_html:	'<p>About Oion LTA</p>', 
	content_text:	'About Oion LTA', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/mov_0205_0000.mov', 
	id:		'mov_0205_0000', 
	image:		'https://media.oionlta.app/media/mov_0205_0000_banner_image.png', 
	language:	'en-US', 
	summary:	'About Oion LTA', 
	tags:		[ 'About', '__TAGS_OF_THE_MEDIA__', ], 
	title:		'About Oion LTA', 
	url:		'https://media.oionlta.app/media/mov_0205_0000.mov', 
	}, 
},



/////////////////////////////////////////////////
wav_0205_0000:{ 
alt:		'About Oion LTA', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0205.0000.utc⨁', 
decoding:	'', 
desc:		'A short audio clip about Oion Learning & Training Academy', 
elm:		'audio', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'true', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/wav_0205_0000.wav', 
srcset:[
	], 
title:		'About Oion LTA', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'audio/wav', 
usemap:		'', 
width:		'window', 
wci:{ 
	attachments:[ { 
		url:		'./media/wav_0205_0000.wav', 
		mime_type:	'audio/wav', 
		title:		'About Oion LTA', 
		size_in_bytes:		7100000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/wav_0205_0000_banner_image.png',
	content_html:	'<p>About Oion LTA</p>', 
	content_text:	'About Oion LTA', 
	date_modified:	'2025.0205.0000.utc⨁', 
	date_published:	'2025.0205.0000.utc⨁', 
	external_url:	'https://media.oionlta.app/media/wav_0205_0000.wav', 
	id:		'wav_0725_0001', 
	image:		'https://media.oionlta.app/media/wav_0205_0000.wav', 
	language:	'en-US', 
	summary:	'About Oion LTA', 
	tags:		[ 'About', 'Learning', 'Oion LTA',  ], 
	title:		'About Oion LTA', 
	url:		'https://media.oionlta.app/media/wav_0205_0000.wav', 
	}, 
},






/////////////////////////////////////////////////
png_0000_0000:{
alt:		'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0000_0000.png', 
srcset:[
		'https://media.oionlta.app/media/png_0000_0000.png', 
	], 
title:		'Autumn Leaf', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0000_0000.png', 
		mime_type:	'image/png', 
		title:		'Autumn Leaf', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0000_0000.png',
	content_html:	'<p>A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   </p>', 
	content_text:	'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0000_0000.png', 
	id:		'png_0000_0000', 
	image:		'https://media.oionlta.app/media/png_0000_0000.png', 
	language:	'en-US', 
	summary:	'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
	tags:		[ 'Autumn Leaf', 'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 'media', 'png', ], 
	title:		'Autumn Leaf', 
	url:		'https://media.oionlta.app/media/png_0000_0000.png', 
	}, 

},



/////////////////////////////////////////////////
png_0207_0000:{
alt:		'Gray right arrow with blue outline', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'Gray right arrow with blue outline', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0207_0000.png', 
srcset:[
		'https://media.oionlta.app/media/png_0207_0000.png', 
	], 
title:		'Next Image', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'__FILE_GROUP__/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0207_0000.png', 
		mime_type:	'image/png', 
		title:		'Next Image', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0207_0000.png',
	content_html:	'<p>Gray right arrow with blue outline</p>', 
	content_text:	'Gray right arrow with blue outline', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0207_0000.png', 
	id:		'png_0207_0000', 
	image:		'https://media.oionlta.app/media/png_0207_0000.png', 
	language:	'en-US', 
	summary:	'Gray right arrow with blue outline', 
	tags:		[ 'Next Image', 'Gray right arrow with blue outline', '__FILE_GROUP__', 'png', ], 
	title:		'Next Image', 
	url:		'https://media.oionlta.app/media/png_0207_0000.png', 
	}, 

},




/////////////////////////////////////////////////
png_0207_0001:{
alt:		'Gray arrow pointing Left, used to navigate to previous image', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'Gray arrow pointing Left, used to navigate to previous image', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0207_0001.png', 
srcset:[
		'https://media.oionlta.app/media/png_0207_0001.png', 
	], 
title:		'Previous Image', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0207_0001.png', 
		mime_type:	'image/png', 
		title:		'Previous Image', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0207_0001.png',
	content_html:	'<p>Gray arrow pointing Left, used to navigate to previous image</p>', 
	content_text:	'Gray arrow pointing Left, used to navigate to previous image', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0207_0001.png', 
	id:		'png_0207_0001', 
	image:		'https://media.oionlta.app/media/png_0207_0001.png', 
	language:	'en-US', 
	summary:	'Gray arrow pointing Left, used to navigate to previous image', 
	tags:		[ 'Previous Image', 'Gray arrow pointing Left, used to navigate to previous image', 'media', 'png', ], 
	title:		'Previous Image', 
	url:		'https://media.oionlta.app/media/png_0207_0001.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0000:{
alt:		'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0000.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0000.png', 
	], 
title:		'Autumn Leaf', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0000.png', 
		mime_type:	'image/png', 
		title:		'Autumn Leaf', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0000.png',
	content_html:	'<p>A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   </p>', 
	content_text:	'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0000.png', 
	id:		'png_0208_0000', 
	image:		'https://media.oionlta.app/media/png_0208_0000.png', 
	language:	'en-US', 
	summary:	'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 
	tags:		[ 'Autumn Leaf', 'A maple style leaf with gradient colors top to bottom, orange, yellow, green & brown.   ', 'media', 'png', ], 
	title:		'Autumn Leaf', 
	url:		'https://media.oionlta.app/media/png_0208_0000.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0001:{
///2025.0208.1700,A simple abstract image of green grass.  ,img,png,png_0208_0001,Grass,media
alt:		'A simple abstract image of green grass.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'A simple abstract image of green grass.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0001.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0001.png', 
	], 
title:		'Grass', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0001.png', 
		mime_type:	'image/png', 
		title:		'Grass', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0001.png',
	content_html:	'<p>A simple abstract image of green grass.  </p>', 
	content_text:	'A simple abstract image of green grass.  ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0001.png', 
	id:		'png_0208_0001', 
	image:		'https://media.oionlta.app/media/png_0208_0001.png', 
	language:	'en-US', 
	summary:	'A simple abstract image of green grass.  ', 
	tags:		[ 'Grass', 'A simple abstract image of green grass.  ', 'media', 'png', ], 
	title:		'Grass', 
	url:		'https://media.oionlta.app/media/png_0208_0001.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0002:{
///2025.0208.1700,An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ,img,png,png_0208_0002,Bonsai Tree,media
alt:		'An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0002.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0002.png', 
	], 
title:		'Bonsai Tree', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0002.png', 
		mime_type:	'image/png', 
		title:		'Bonsai Tree', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0002.png',
	content_html:	'<p>An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  </p>', 
	content_text:	'An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0002.png', 
	id:		'png_0208_0002', 
	image:		'https://media.oionlta.app/media/png_0208_0002.png', 
	language:	'en-US', 
	summary:	'An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ', 
	tags:		[ 'Bonsai Tree', 'An abstract image of a Bonsai tree, having four green canopies, & a brown trunk.  ', 'media', 'png', ], 
	title:		'Bonsai Tree', 
	url:		'https://media.oionlta.app/media/png_0208_0002.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0003:{
alt:		'An abstract image of an oak tree with green canopy & brown trunk.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'An abstract image of an oak tree with green canopy & brown trunk.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0003.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0003.png', 
	], 
title:		'Oak Tree', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0003.png', 
		mime_type:	'image/png', 
		title:		'Oak Tree', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0003.png',
	content_html:	'<p>An abstract image of an oak tree with green canopy & brown trunk.  </p>', 
	content_text:	'An abstract image of an oak tree with green canopy & brown trunk.  ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0003.png', 
	id:		'png_0208_0003', 
	image:		'https://media.oionlta.app/media/png_0208_0003.png', 
	language:	'en-US', 
	summary:	'An abstract image of an oak tree with green canopy & brown trunk.  ', 
	tags:		[ 'Oak Tree', 'An abstract image of an oak tree with green canopy & brown trunk.  ', 'media', 'png', ], 
	title:		'Oak Tree', 
	url:		'https://media.oionlta.app/media/png_0208_0003.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0004:{
alt:		'An abstract image of a brach of six green leaves, minimal gradient.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'An abstract image of a brach of six green leaves, minimal gradient.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0004.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0004.png', 
	], 
title:		'Leaf Branch', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0004.png', 
		mime_type:	'image/png', 
		title:		'Leaf Branch', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0004.png',
	content_html:	'<p>An abstract image of a brach of six green leaves, minimal gradient.  </p>', 
	content_text:	'An abstract image of a brach of six green leaves, minimal gradient.  ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0004.png', 
	id:		'png_0208_0004', 
	image:		'https://media.oionlta.app/media/png_0208_0004.png', 
	language:	'en-US', 
	summary:	'An abstract image of a brach of six green leaves, minimal gradient.  ', 
	tags:		[ 'Leaf Branch', 'media', 'png', ], 
	title:		'Leaf Branch', 
	url:		'https://media.oionlta.app/media/png_0208_0004.png', 
	}, 

},



/////////////////////////////////////////////////
png_0208_0005:{
alt:		'An abstract image of an evergreen tree, green with brown trunk.  ', 
autoplay:	'false', 
controls:	'true', 
crossorigin:	'use-credentials', 	///anonymous,use-credentials
date_published:	'2025.0208.1700.utc⨁', 
decoding:	'', 
desc:		'An abstract image of an evergreen tree, green with brown trunk.  ', 
elm:		'img', 
fetchpriority:	'high', 
height:		'47mm', 
ismap:		'', 
loading:	'lazy', 
loop:		'false', 		///true,false(WHETEHER TO LOOP THE MEDIA RESOURCE) 
mediaresource:	'none', 		///none,multiple,rewritten,or_an_origin 
muted:		'false', 		///true,false(WHETHER TO MUTE THE MEDIA RESOURCE ON LOAD) 
notice:		'https://oionlta.app/notice/notice.txt', 
playbackrate:	'1.0', 
preload:	'metadata', 
referrerpolicy:	'', 
rel:		'sponsored', 
sizes:		'', 
src:		'./media/png_0208_0005.png', 
srcset:[
		'https://media.oionlta.app/media/png_0208_0005.png', 
	], 
title:		'Evergreen Tree', 
track:	{
	captions:{
		default:'true', 
		kind:	'captions', 
		label:	'Captions:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	chapters:{
		kind:	'chapters', 
		label:	'Chapters:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	descriptions:{
		kind:	'descriptions', 
		label:	'Description:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	metadata:{
		kind:	'metadata', 
		label:	'MetaData:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	subtitles:{
		kind:	'subtitles', 
		label:	'Subtitles:  ', 
		src:	'https://data.oionlta.app/data/vtt_mmdd_0000.vtt', 
		srclang:'en-US', 
		}, 
	}, 
type:		'media/png', 
usemap:		'', 
width:		'47mm', 
wci:{ 
	attachments:[ { 
		url:		'./media/png_0208_0005.png', 
		mime_type:	'image/png', 
		title:		'Evergreen Tree', 
		size_in_bytes:		1000000, 
		duration_in_seconds:	0000, 
		}, ], 
	authors:[ { 
		avatar:	'./media/png_0000_0000.png', 
		name:	'Oion LTA', 
		url:	'https://oionlta.app/', 
		}, ], 
	banner_image:	'https://media.oionlta.app/media/png_0208_0005.png',
	content_html:	'<p>An abstract image of an evergreen tree, green with brown trunk.  </p>', 
	content_text:	'An abstract image of an evergreen tree, green with brown trunk.  ', 
	date_modified:	'2025.0208.1700.utc⨁', 
	date_published:	'2025.0208.1700.utc⨁', 
	external_url:	'https://media.oionlta.app/media/png_0208_0005.png', 
	id:		'png_0208_0005', 
	image:		'https://media.oionlta.app/media/png_0208_0005.png', 
	language:	'en-US', 
	summary:	'An abstract image of an evergreen tree, green with brown trunk.  ', 
	tags:		[ 'Evergreen Tree', 'media', 'png', ], 
	title:		'Evergreen Tree', 
	url:		'https://media.oionlta.app/media/png_0208_0005.png', 
	}, 

},



srcset:[
	'./media/png_0000_0000.png', 	'./media/png_0207_0000.png', 	'./media/png_0207_0001.png', 	'./media/png_0208_0000.png', 	'./media/png_0208_0001.png', 	'./media/png_0208_0002.png', 	'./media/png_0208_0003.png', 	'./media/png_0208_0004.png', 	'./media/png_0208_0005.png', 
	], 
};
/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	data_diagnostic_0002.style.display = 		'none';

/////////////////////////////////////////////////
