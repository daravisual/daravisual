
/////////////////////////////////////////////////
///	DATA:  LINK

/////////////////////////////////////////////////

var data_0001 = {

link_nnnn:{
///__DATE__,__DESC__,__LINK_TITLE__,__HREF__,__ELM__,__FILEFORM__,__EXTENSION__,
	alt:		'__DESC__', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'__DATE__.utc⨁', 
	desc:		'__DESC__', 
	disabled:	'false', 
	elm:		'__ELM__', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'__HREF__', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'__LINK_TITLE__', 
	type:		'__FILEFORM__/__EXTENSION__', 
	}, 



link_0000:{
	alt:		'Main', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Main Page', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'./index.html#top', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0001', 
	title:		'Main', 
	type:		'text/html', 
	}, 



link_0001:{
	alt:		'Services', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Services offered by Foliage', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0001', 
	title:		'Services', 
	type:		'text/html', 
	}, 



link_0002:{
	alt:		'About', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'About this company', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'About', 
	type:		'text/html', 
	}, 



link_0003:{
	alt:		'Gallery', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Image Gallery for this company', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0002', 
	title:		'Gallery', 
	type:		'text/html', 
	}, 



link_0004:{
	alt:		'Schedule an Appointment Online', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Schedule an Appointment Online', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0003', 
	title:		'Schedule an Appointment Online', 
	type:		'text/html', 
	}, 



link_0005:{
	alt:		'Updates', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'News updates & progress on the website', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0007', 
	title:		'Updates', 
	type:		'text/html', 
	}, 



link_0006:{
	alt:		'Privacy Policy', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Privacy Policy for this company', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'./privacypolicy.txt', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'alternate', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0005', 
	title:		'Privacy Policy', 
	type:		'text/txt', 
	}, 


link_0007:{
	alt:		'Terms of Service', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Terms of Service for this company', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'./termsofservice.txt', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'alternate', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0005', 
	title:		'Terms of Service', 
	type:		'text/txt', 
	}, 



link_0008:{
	alt:		'__EMAIL__', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Opens the email address for this company in the system default application', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'mailto:info@daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'__EMAIL__', 
	type:		'text/txt', 
	}, 



link_0009:{
	alt:		'Call', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Opens the phone number for this company in the system default application', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'tel:+15555551234', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'Call', 
	type:		'text/txt', 
	}, 




};


/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	data_diagnostic_0001.style.display = 		'none';

/////////////////////////////////////////////////
