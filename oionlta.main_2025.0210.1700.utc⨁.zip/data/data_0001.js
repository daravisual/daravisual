
/////////////////////////////////////////////////
///	DATA:  LINK

/////////////////////////////////////////////////

var data_0001 = {

link_nnnn:{
///__DATE__,__DESC__,__LINK_TITLE__,__HREF__,__ELM__,__FILEFORM__,__EXTENSION__,
	alt:		'__DESC__', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'__DATE__.utc⨁', 
	desc:		'__DESC__', 
	disabled:	'false', 
	elm:		'__ELM__', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'__HREF__', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'__LINK_TITLE__', 
	type:		'__FILEFORM__/__EXTENSION__', 
	}, 



link_1000:{
	alt:		'Main', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Main Page', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app#top', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0001', 
	title:		'Main', 
	type:		'text/html', 
	}, 



link_1001:{
	alt:		'Learning Modules', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Learning Modules', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://modules.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0001', 
	title:		'Learning Modules', 
	type:		'text/html', 
	}, 



link_1002:{
	alt:		'About', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, About', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'About', 
	type:		'text/html', 
	}, 



link_1003:{
	alt:		'Gallery', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Gallery', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0002', 
	title:		'Gallery', 
	type:		'text/html', 
	}, 



link_1004:{
	alt:		'Archive', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Archive', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://archive.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0003', 
	title:		'Archive', 
	type:		'text/html', 
	}, 



link_1005:{
	alt:		'Updates', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Updates', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0007', 
	title:		'Updates', 
	type:		'text/html', 
	}, 



link_1006:{
	alt:		'Privacy Policy', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Privacy Policy', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app/privacypolicy.txt', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'alternate', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0005', 
	title:		'Privacy Policy', 
	type:		'text/txt', 
	}, 


link_1007:{
	alt:		'Terms of Service', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Oion LTA, Terms of Service', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app/termsofservice.txt', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'alternate', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0005', 
	title:		'Terms of Service', 
	type:		'text/txt', 
	}, 


link_1008:{
	alt:		'Email Oion LTA', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Email Address for Oion LTA', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'mailto:info@daravisual.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'info@daravisual.app', 
	type:		'text/txt', 
	}, 



link_1009:{
	alt:		'___', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0203.0000.utc⨁', 
	desc:		'Samples', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://oionlta.app/', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'none', 		///(alternate,sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0009', 
	title:		'___', 
	type:		'text/html', 
	}, 



/////////////////////////////////////////////////
link_2001:{
	alt:		'Modules for French Language Learning', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Modules for French Language Learning', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://french.modules.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'French Language Learning', 
	type:		'text/html', 
	}, 



link_2002:{
	alt:		'Modules for German Language Learning', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Modules for German Language Learning', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://german.modules.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'German Language Learning', 
	type:		'text/html', 
	}, 



link_2003:{
	alt:		'Modules for Russian Language Learning', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Modules for Russian Language Learning', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://russian.modules.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'Russian Language Learning', 
	type:		'text/html', 
	}, 



link_2004:{
	alt:		'Modules for Spainish Language Learning', 
	as:		'', 
	color:		'', 
	crossorigin:	'',  			///anonymous,use-credentials
	date_published:	'2025.0207.1700.utc⨁', 
	desc:		'Modules for Spainish Language Learning', 
	disabled:	'false', 
	elm:		'a', 
	fetchpriority:	'high', 		///(low,high,auto)
	href:		'https://spainish.modules.oionlta.app', 
	hreflang:	'en-US', 
	imagesrcset:	'', 
	imagesizes:	'', 
	integrity:	'', 
	media:		'', 
	referrerpolicy:	'high', 		///(low,high,auto)
	rel:		'sponsored', 		///(sponsored,icon,)
	sizes:		'', 			///SIZEOFICONFOR(REL'icon')
	tabindex:	'0000', 
	title:		'Spainish Language Learning', 
	type:		'text/html', 
	}, 



};


/////////////////////////////////////////////////
///	SCRIPT COMPLETE
	data_diagnostic_0001.style.display = 		'none';

/////////////////////////////////////////////////
